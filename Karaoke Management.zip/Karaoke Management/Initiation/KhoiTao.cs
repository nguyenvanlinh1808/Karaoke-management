﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Karaoke_Management.PresentationLayer;

namespace Karaoke_Management.Initiation
{
    class KhoiTao
    {
        #region Những đối tượng dùng chung
        public static frmThemNV themNV = null;
        public static frmTimNV timNV = null;
        public static frmThemNCC themNCC = null;
        public static frmTimNCC timNCC = null;
        public static frmThemSP themSP = null;
        public static frmTimSP timSP = null;
        public static frmNhapHDCT nhapHDCT = null;
        public static frmTimHD timHD = null;
        public static frmKiemKe kiemKe = null;
        public static frmKiemKeCT kiemKeCT = null;
        public static frmHDCT hDCT = null;
        public static frmSuaHD suaHD = null;
        public static frmSuaNV suaNV = null;
        public static frmSuaNCC suaNCC = null;
        public static frmSuaSP suaSP = null;
        public static frmLogin login = null;
        #endregion
    }
}
