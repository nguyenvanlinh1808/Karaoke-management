﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Karaoke_Management;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Karaoke_Management.PresentationLayer
{
    public partial class frmThemNV : DevComponents.DotNetBar.Office2007Form
    {
        public frmThemNV()
        {
            InitializeComponent();
        }

        private void buttonHuyBo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            {
                decimal Salary;
                string MaCV;
                string Sex;
                string connectionString = "Data Source=NDA-PC\\SQLEXPRESS; Initial Catalog=KaraokeMangement; User Id=sa; password=12345; Integrated Security = true";

                if(coBoxCV.Text == "Quản lý")
                {
                    MaCV = "QL";
                }
                else
                {
                    MaCV = "NV";
                }
            
                if(coBoxSex.Text == "Nam")
                {
                    Sex = "Nam";
                }
                else
                {
                    Sex = "Nữ";
                }

                
                Salary = Convert.ToDecimal(txtLuong.Text);

                // Tạo đối tượng kết nối.
                SqlConnection conn = new SqlConnection(connectionString);
                SqlDataAdapter da = new SqlDataAdapter();
               

                // Tạo câu lệnh T-SQL.
                string commandText = "INSERT INTO NhanVien VALUES (@MaNV, @TenDN,@MatKhau1, @HoTen, @GioiTinh, @NgaySinh, @DiaChi,@DienThoai,@ChucVu, @MucLuong)";

                // Tạo đối tượng thực hiện câu lệnh T-SQL.
                da.InsertCommand = new SqlCommand(commandText, conn);

                da.InsertCommand.Parameters.Add("@MaNV", SqlDbType.VarChar).Value = txtMaNV.Text;
                da.InsertCommand.Parameters.Add("@TenDN", SqlDbType.VarChar).Value = txtID.Text;
                da.InsertCommand.Parameters.Add("@MatKhau1", SqlDbType.VarChar).Value = txtPassword.Text;
                da.InsertCommand.Parameters.Add("@HoTen", SqlDbType.NVarChar).Value = txtHoTen.Text;
                da.InsertCommand.Parameters.Add("@GioiTinh", SqlDbType.NVarChar).Value = Sex;
                da.InsertCommand.Parameters.Add("@NgaySinh", SqlDbType.DateTime).Value = DOB.Value;
                da.InsertCommand.Parameters.Add("@DiaChi", SqlDbType.NVarChar).Value = txtDiaChi.Text;
                da.InsertCommand.Parameters.Add("@DienThoai", SqlDbType.NVarChar).Value = txtDienThoai.Text;
                da.InsertCommand.Parameters.Add("@ChucVu", SqlDbType.VarChar).Value = MaCV;
                da.InsertCommand.Parameters.Add("@MucLuong", SqlDbType.Money).Value = Salary;
              
                // Mở kết nối trước khi thực hiện lệnh.
                conn.Open();

                // Thực hiện lệnh.
                da.InsertCommand.ExecuteNonQuery();

                // Đóng kết nối.
                conn.Close();
                this.Close();
            }
            
        }
    }
}
