﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Karaoke_Management;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Karaoke_Management.PresentationLayer
{
    public partial class frmLogin : DevComponents.DotNetBar.Office2007Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void buttonThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

         private bool CompareStrings(string string1, string string2)
 	    {  
 	       return String.Compare(string1, string2, true, System.Globalization.CultureInfo.InvariantCulture) == 0 ? true : false;  
	    }

         private void buttonDangNhap_Click(object sender, EventArgs e)
         {
             string tendn = txtTenDN.Text;
             string matkhau = txtMatKhau.Text;
             bool flag = true;

             if (tendn.Equals(""))
             {
                 MessageBox.Show("Tên đăng nhập không được để trống");
                 txtTenDN.Text = "";
                 txtTenDN.Focus();
                 flag = false;
             }
             else
             {
                 if (matkhau.Equals(""))
                 {
                     MessageBox.Show("Mật khẩu không được để trống");
                     txtMatKhau.Text = "";
                     txtMatKhau.Focus();
                     flag = false;
                 }
                 else
                 {
                     flag = true;
                 }
             }

             if (flag == true)
             {
                 try
                 {
                     SqlConnection UGIcon = new SqlConnection();
                     UGIcon.ConnectionString = "Server=NDA-PC\\SQLEXPRESS; Database=KaraokeMangement; User Id=sa; password=12345";
                     UGIcon.Open();

                     SqlCommand cmd = new SqlCommand("SELECT ISNULL(TenDN, '') AS TenDN, ISNULL(MatKhau,'') AS MatKhau FROM NhanVien WHERE TenDN='" + txtTenDN.Text + "' and MatKhau='" + txtMatKhau.Text + "'", UGIcon);

                     SqlDataReader dr = cmd.ExecuteReader();

                     while (dr.Read())
                     {
                         if (this.CompareStrings(dr["TenDn"].ToString(), txtTenDN.Text) &&
                             this.CompareStrings(dr["MatKhau"].ToString(), txtMatKhau.Text))
                         {
                             frmMain main = new frmMain();
                             main.Show();
                             this.Visible = false;
                         }
                         else
                         {
                             MessageBox.Show("Lỗi");
                         }

                     }

                     dr.Close();

                     UGIcon.Close();

                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show(ex.Message);
                 }
             }
        }    
    }
}