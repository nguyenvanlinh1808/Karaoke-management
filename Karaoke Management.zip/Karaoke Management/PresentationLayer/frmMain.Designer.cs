﻿namespace Karaoke_Management.PresentationLayer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.ribbonControl1 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel1 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarQuanLyHoaDon = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemNhap_HoaDon = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemTimKiem_HoaDon = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel2 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarQuanLySanPham = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemThem_SanPham = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemTimKiem_SanPham = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel6 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarTroGiup = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemThongTinTacGia = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemThongTinHeThong = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel5 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarBaoCao = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemBaoCao = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemBieuDo = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarQuanLyNhaCungCap = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemThem_NhaCungCap = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemTimKiem_NhaCungCap = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBarQuanLyNhanVien = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItemThem_NhanVien = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItemTimKiem_NhanVien = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonTabItemHoaDon = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItemSanPham = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItemNhaCungCap = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItemNhanVien = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem5 = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribbonTabItem6 = new DevComponents.DotNetBar.RibbonTabItem();
            this.office2007StartButton1 = new DevComponents.DotNetBar.Office2007StartButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer2 = new DevComponents.DotNetBar.ItemContainer();
            this.itemContainer3 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem5 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem6 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonDong = new DevComponents.DotNetBar.ButtonItem();
            this.qatCustomizeItem1 = new DevComponents.DotNetBar.QatCustomizeItem();
            this.ribbonControl1.SuspendLayout();
            this.ribbonPanel1.SuspendLayout();
            this.ribbonPanel2.SuspendLayout();
            this.ribbonPanel6.SuspendLayout();
            this.ribbonPanel5.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.CaptionVisible = true;
            this.ribbonControl1.Controls.Add(this.ribbonPanel6);
            this.ribbonControl1.Controls.Add(this.ribbonPanel5);
            this.ribbonControl1.Controls.Add(this.ribbonPanel4);
            this.ribbonControl1.Controls.Add(this.ribbonPanel3);
            this.ribbonControl1.Controls.Add(this.ribbonPanel2);
            this.ribbonControl1.Controls.Add(this.ribbonPanel1);
            this.ribbonControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ribbonTabItemHoaDon,
            this.ribbonTabItemSanPham,
            this.ribbonTabItemNhaCungCap,
            this.ribbonTabItemNhanVien,
            this.ribbonTabItem5,
            this.ribbonTabItem6});
            this.ribbonControl1.KeyTipsFont = new System.Drawing.Font("Tahoma", 7F);
            this.ribbonControl1.Location = new System.Drawing.Point(4, 1);
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.ribbonControl1.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.office2007StartButton1,
            this.qatCustomizeItem1});
            this.ribbonControl1.Size = new System.Drawing.Size(532, 132);
            this.ribbonControl1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonControl1.TabGroupHeight = 14;
            this.ribbonControl1.TabGroupsVisible = true;
            this.ribbonControl1.TabIndex = 0;
            this.ribbonControl1.TabStop = true;
            this.ribbonControl1.Text = "ribbonControl1";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel1.Controls.Add(this.ribbonBarQuanLyHoaDon);
            this.ribbonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel1.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel1.Name = "ribbonPanel1";
            this.ribbonPanel1.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel1.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel1.TabIndex = 1;
            this.ribbonPanel1.Visible = false;
            // 
            // ribbonBarQuanLyHoaDon
            // 
            this.ribbonBarQuanLyHoaDon.AutoOverflowEnabled = true;
            this.ribbonBarQuanLyHoaDon.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarQuanLyHoaDon.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemNhap_HoaDon,
            this.buttonItemTimKiem_HoaDon});
            this.ribbonBarQuanLyHoaDon.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarQuanLyHoaDon.Name = "ribbonBarQuanLyHoaDon";
            this.ribbonBarQuanLyHoaDon.Size = new System.Drawing.Size(288, 71);
            this.ribbonBarQuanLyHoaDon.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarQuanLyHoaDon.TabIndex = 0;
            this.ribbonBarQuanLyHoaDon.Text = "Quản lý Hóa đơn";
            // 
            // buttonItemNhap_HoaDon
            // 
            this.buttonItemNhap_HoaDon.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemNhap_HoaDon.Image = global::Karaoke_Management.Properties.Resources.NhapHoaDon;
            this.buttonItemNhap_HoaDon.ImagePaddingHorizontal = 8;
            this.buttonItemNhap_HoaDon.Name = "buttonItemNhap_HoaDon";
            this.buttonItemNhap_HoaDon.RibbonWordWrap = false;
            this.buttonItemNhap_HoaDon.SubItemsExpandWidth = 14;
            this.buttonItemNhap_HoaDon.Text = "Nhập hóa đơn mới";
            this.buttonItemNhap_HoaDon.Click += new System.EventHandler(this.buttonItemNhap_HoaDon_Click);
            // 
            // buttonItemTimKiem_HoaDon
            // 
            this.buttonItemTimKiem_HoaDon.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemTimKiem_HoaDon.Image = global::Karaoke_Management.Properties.Resources.tracuu1;
            this.buttonItemTimKiem_HoaDon.ImagePaddingHorizontal = 8;
            this.buttonItemTimKiem_HoaDon.Name = "buttonItemTimKiem_HoaDon";
            this.buttonItemTimKiem_HoaDon.RibbonWordWrap = false;
            this.buttonItemTimKiem_HoaDon.SubItemsExpandWidth = 14;
            this.buttonItemTimKiem_HoaDon.Text = "Tìm kiếm hóa đơn";
            this.buttonItemTimKiem_HoaDon.Click += new System.EventHandler(this.buttonItemTimKiem_HoaDon_Click);
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel2.Controls.Add(this.ribbonBarQuanLySanPham);
            this.ribbonPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel2.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel2.Name = "ribbonPanel2";
            this.ribbonPanel2.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel2.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel2.TabIndex = 2;
            this.ribbonPanel2.Visible = false;
            // 
            // ribbonBarQuanLySanPham
            // 
            this.ribbonBarQuanLySanPham.AutoOverflowEnabled = true;
            this.ribbonBarQuanLySanPham.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarQuanLySanPham.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemThem_SanPham,
            this.buttonItemTimKiem_SanPham});
            this.ribbonBarQuanLySanPham.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarQuanLySanPham.Name = "ribbonBarQuanLySanPham";
            this.ribbonBarQuanLySanPham.Size = new System.Drawing.Size(288, 71);
            this.ribbonBarQuanLySanPham.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarQuanLySanPham.TabIndex = 0;
            this.ribbonBarQuanLySanPham.Text = "Quản lý Sản phẩm";
            // 
            // buttonItemThem_SanPham
            // 
            this.buttonItemThem_SanPham.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemThem_SanPham.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemThem_SanPham.Image")));
            this.buttonItemThem_SanPham.ImagePaddingHorizontal = 8;
            this.buttonItemThem_SanPham.Name = "buttonItemThem_SanPham";
            this.buttonItemThem_SanPham.RibbonWordWrap = false;
            this.buttonItemThem_SanPham.SubItemsExpandWidth = 14;
            this.buttonItemThem_SanPham.Text = "Thêm Sản phẩm";
            this.buttonItemThem_SanPham.Click += new System.EventHandler(this.buttonItemThem_SanPham_Click);
            // 
            // buttonItemTimKiem_SanPham
            // 
            this.buttonItemTimKiem_SanPham.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemTimKiem_SanPham.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemTimKiem_SanPham.Image")));
            this.buttonItemTimKiem_SanPham.ImagePaddingHorizontal = 8;
            this.buttonItemTimKiem_SanPham.Name = "buttonItemTimKiem_SanPham";
            this.buttonItemTimKiem_SanPham.RibbonWordWrap = false;
            this.buttonItemTimKiem_SanPham.SubItemsExpandWidth = 14;
            this.buttonItemTimKiem_SanPham.Text = "Tìm kiếm Sản phẩm";
            this.buttonItemTimKiem_SanPham.Click += new System.EventHandler(this.buttonItemTimKiem_SanPham_Click);
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel6.Controls.Add(this.ribbonBarTroGiup);
            this.ribbonPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel6.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel6.Name = "ribbonPanel6";
            this.ribbonPanel6.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel6.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel6.TabIndex = 6;
            // 
            // ribbonBarTroGiup
            // 
            this.ribbonBarTroGiup.AutoOverflowEnabled = true;
            this.ribbonBarTroGiup.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarTroGiup.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemThongTinTacGia,
            this.buttonItemThongTinHeThong});
            this.ribbonBarTroGiup.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarTroGiup.Name = "ribbonBarTroGiup";
            this.ribbonBarTroGiup.Size = new System.Drawing.Size(281, 71);
            this.ribbonBarTroGiup.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarTroGiup.TabIndex = 0;
            this.ribbonBarTroGiup.Text = "Trợ giúp";
            // 
            // buttonItemThongTinTacGia
            // 
            this.buttonItemThongTinTacGia.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemThongTinTacGia.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemThongTinTacGia.Image")));
            this.buttonItemThongTinTacGia.ImagePaddingHorizontal = 8;
            this.buttonItemThongTinTacGia.Name = "buttonItemThongTinTacGia";
            this.buttonItemThongTinTacGia.RibbonWordWrap = false;
            this.buttonItemThongTinTacGia.SubItemsExpandWidth = 14;
            this.buttonItemThongTinTacGia.Text = "Thông tin tác giả";
            // 
            // buttonItemThongTinHeThong
            // 
            this.buttonItemThongTinHeThong.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemThongTinHeThong.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemThongTinHeThong.Image")));
            this.buttonItemThongTinHeThong.ImagePaddingHorizontal = 8;
            this.buttonItemThongTinHeThong.Name = "buttonItemThongTinHeThong";
            this.buttonItemThongTinHeThong.RibbonWordWrap = false;
            this.buttonItemThongTinHeThong.SubItemsExpandWidth = 14;
            this.buttonItemThongTinHeThong.Text = "Thông tin hệ thống";
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel5.Controls.Add(this.ribbonBarBaoCao);
            this.ribbonPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel5.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel5.Name = "ribbonPanel5";
            this.ribbonPanel5.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel5.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel5.TabIndex = 5;
            this.ribbonPanel5.Visible = false;
            // 
            // ribbonBarBaoCao
            // 
            this.ribbonBarBaoCao.AutoOverflowEnabled = true;
            this.ribbonBarBaoCao.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarBaoCao.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemBaoCao,
            this.buttonItemBieuDo});
            this.ribbonBarBaoCao.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarBaoCao.Name = "ribbonBarBaoCao";
            this.ribbonBarBaoCao.Size = new System.Drawing.Size(189, 71);
            this.ribbonBarBaoCao.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarBaoCao.TabIndex = 0;
            this.ribbonBarBaoCao.Text = "Báo cáo";
            // 
            // buttonItemBaoCao
            // 
            this.buttonItemBaoCao.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemBaoCao.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemBaoCao.Image")));
            this.buttonItemBaoCao.ImagePaddingHorizontal = 8;
            this.buttonItemBaoCao.Name = "buttonItemBaoCao";
            this.buttonItemBaoCao.RibbonWordWrap = false;
            this.buttonItemBaoCao.SubItemsExpandWidth = 14;
            this.buttonItemBaoCao.Text = "Báo cáo";
            this.buttonItemBaoCao.Click += new System.EventHandler(this.buttonItemBaoCao_Click);
            // 
            // buttonItemBieuDo
            // 
            this.buttonItemBieuDo.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemBieuDo.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemBieuDo.Image")));
            this.buttonItemBieuDo.ImagePaddingHorizontal = 8;
            this.buttonItemBieuDo.Name = "buttonItemBieuDo";
            this.buttonItemBieuDo.RibbonWordWrap = false;
            this.buttonItemBieuDo.SubItemsExpandWidth = 14;
            this.buttonItemBieuDo.Text = "Biểu đồ";
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel3.Controls.Add(this.ribbonBarQuanLyNhaCungCap);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel3.TabIndex = 3;
            this.ribbonPanel3.Visible = false;
            // 
            // ribbonBarQuanLyNhaCungCap
            // 
            this.ribbonBarQuanLyNhaCungCap.AutoOverflowEnabled = true;
            this.ribbonBarQuanLyNhaCungCap.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarQuanLyNhaCungCap.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemThem_NhaCungCap,
            this.buttonItemTimKiem_NhaCungCap});
            this.ribbonBarQuanLyNhaCungCap.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarQuanLyNhaCungCap.Name = "ribbonBarQuanLyNhaCungCap";
            this.ribbonBarQuanLyNhaCungCap.Size = new System.Drawing.Size(324, 71);
            this.ribbonBarQuanLyNhaCungCap.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarQuanLyNhaCungCap.TabIndex = 0;
            this.ribbonBarQuanLyNhaCungCap.Text = "Quản lý Nhà cung cấp";
            // 
            // buttonItemThem_NhaCungCap
            // 
            this.buttonItemThem_NhaCungCap.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemThem_NhaCungCap.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemThem_NhaCungCap.Image")));
            this.buttonItemThem_NhaCungCap.ImagePaddingHorizontal = 8;
            this.buttonItemThem_NhaCungCap.Name = "buttonItemThem_NhaCungCap";
            this.buttonItemThem_NhaCungCap.RibbonWordWrap = false;
            this.buttonItemThem_NhaCungCap.SubItemsExpandWidth = 14;
            this.buttonItemThem_NhaCungCap.Text = "Thêm Nhà cung cấp";
            this.buttonItemThem_NhaCungCap.Click += new System.EventHandler(this.buttonItemThem_NhaCungCap_Click);
            // 
            // buttonItemTimKiem_NhaCungCap
            // 
            this.buttonItemTimKiem_NhaCungCap.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemTimKiem_NhaCungCap.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemTimKiem_NhaCungCap.Image")));
            this.buttonItemTimKiem_NhaCungCap.ImagePaddingHorizontal = 8;
            this.buttonItemTimKiem_NhaCungCap.Name = "buttonItemTimKiem_NhaCungCap";
            this.buttonItemTimKiem_NhaCungCap.RibbonWordWrap = false;
            this.buttonItemTimKiem_NhaCungCap.SubItemsExpandWidth = 14;
            this.buttonItemTimKiem_NhaCungCap.Text = "Tìm kiếm Nhà cung cấp";
            this.buttonItemTimKiem_NhaCungCap.Click += new System.EventHandler(this.buttonItemTimKiem_NhaCungCap_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonPanel4.Controls.Add(this.ribbonBarQuanLyNhanVien);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 56);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(532, 74);
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // ribbonBarQuanLyNhanVien
            // 
            this.ribbonBarQuanLyNhanVien.AutoOverflowEnabled = true;
            this.ribbonBarQuanLyNhanVien.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBarQuanLyNhanVien.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemThem_NhanVien,
            this.buttonItemTimKiem_NhanVien});
            this.ribbonBarQuanLyNhanVien.Location = new System.Drawing.Point(3, 0);
            this.ribbonBarQuanLyNhanVien.Name = "ribbonBarQuanLyNhanVien";
            this.ribbonBarQuanLyNhanVien.Size = new System.Drawing.Size(307, 71);
            this.ribbonBarQuanLyNhanVien.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ribbonBarQuanLyNhanVien.TabIndex = 0;
            this.ribbonBarQuanLyNhanVien.Text = "Quản lý nhân viên";
            // 
            // buttonItemThem_NhanVien
            // 
            this.buttonItemThem_NhanVien.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemThem_NhanVien.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemThem_NhanVien.Image")));
            this.buttonItemThem_NhanVien.ImagePaddingHorizontal = 8;
            this.buttonItemThem_NhanVien.Name = "buttonItemThem_NhanVien";
            this.buttonItemThem_NhanVien.RibbonWordWrap = false;
            this.buttonItemThem_NhanVien.SubItemsExpandWidth = 14;
            this.buttonItemThem_NhanVien.Text = "Thêm mới Nhân viên";
            this.buttonItemThem_NhanVien.Click += new System.EventHandler(this.buttonItemThem_NhanVien_Click);
            // 
            // buttonItemTimKiem_NhanVien
            // 
            this.buttonItemTimKiem_NhanVien.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemTimKiem_NhanVien.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemTimKiem_NhanVien.Image")));
            this.buttonItemTimKiem_NhanVien.ImagePaddingHorizontal = 8;
            this.buttonItemTimKiem_NhanVien.Name = "buttonItemTimKiem_NhanVien";
            this.buttonItemTimKiem_NhanVien.RibbonWordWrap = false;
            this.buttonItemTimKiem_NhanVien.SubItemsExpandWidth = 14;
            this.buttonItemTimKiem_NhanVien.Text = "Tìm kiếm Nhân viên";
            this.buttonItemTimKiem_NhanVien.Click += new System.EventHandler(this.buttonItemTimKiem_NhanVien_Click);
            // 
            // ribbonTabItemHoaDon
            // 
            this.ribbonTabItemHoaDon.FontBold = true;
            this.ribbonTabItemHoaDon.ImagePaddingHorizontal = 8;
            this.ribbonTabItemHoaDon.Name = "ribbonTabItemHoaDon";
            this.ribbonTabItemHoaDon.Panel = this.ribbonPanel1;
            this.ribbonTabItemHoaDon.Text = "Hóa đơn";
            // 
            // ribbonTabItemSanPham
            // 
            this.ribbonTabItemSanPham.FontBold = true;
            this.ribbonTabItemSanPham.ImagePaddingHorizontal = 8;
            this.ribbonTabItemSanPham.Name = "ribbonTabItemSanPham";
            this.ribbonTabItemSanPham.Panel = this.ribbonPanel2;
            this.ribbonTabItemSanPham.Text = "Sản phẩm";
            // 
            // ribbonTabItemNhaCungCap
            // 
            this.ribbonTabItemNhaCungCap.FontBold = true;
            this.ribbonTabItemNhaCungCap.ImagePaddingHorizontal = 8;
            this.ribbonTabItemNhaCungCap.Name = "ribbonTabItemNhaCungCap";
            this.ribbonTabItemNhaCungCap.Panel = this.ribbonPanel3;
            this.ribbonTabItemNhaCungCap.Text = "Nhà cung cấp";
            // 
            // ribbonTabItemNhanVien
            // 
            this.ribbonTabItemNhanVien.FontBold = true;
            this.ribbonTabItemNhanVien.ImagePaddingHorizontal = 8;
            this.ribbonTabItemNhanVien.Name = "ribbonTabItemNhanVien";
            this.ribbonTabItemNhanVien.Panel = this.ribbonPanel4;
            this.ribbonTabItemNhanVien.Text = "Nhân viên";
            // 
            // ribbonTabItem5
            // 
            this.ribbonTabItem5.FontBold = true;
            this.ribbonTabItem5.ImagePaddingHorizontal = 8;
            this.ribbonTabItem5.Name = "ribbonTabItem5";
            this.ribbonTabItem5.Panel = this.ribbonPanel5;
            this.ribbonTabItem5.Text = "Báo cáo";
            // 
            // ribbonTabItem6
            // 
            this.ribbonTabItem6.Checked = true;
            this.ribbonTabItem6.FontBold = true;
            this.ribbonTabItem6.ImagePaddingHorizontal = 8;
            this.ribbonTabItem6.Name = "ribbonTabItem6";
            this.ribbonTabItem6.Panel = this.ribbonPanel6;
            this.ribbonTabItem6.Text = "Trợ giúp";
            // 
            // office2007StartButton1
            // 
            this.office2007StartButton1.AutoExpandOnClick = true;
            this.office2007StartButton1.CanCustomize = false;
            this.office2007StartButton1.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.office2007StartButton1.Image = global::Karaoke_Management.Properties.Resources.refresh;
            this.office2007StartButton1.ImagePaddingHorizontal = 2;
            this.office2007StartButton1.ImagePaddingVertical = 2;
            this.office2007StartButton1.Name = "office2007StartButton1";
            this.office2007StartButton1.ShowSubItems = false;
            this.office2007StartButton1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1});
            this.office2007StartButton1.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "RibbonFileMenuContainer";
            this.itemContainer1.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer1.Name = "itemContainer1";
            this.itemContainer1.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer2});
            // 
            // itemContainer2
            // 
            // 
            // 
            // 
            this.itemContainer2.BackgroundStyle.Class = "RibbonFileMenuTwoColumnContainer";
            this.itemContainer2.ItemSpacing = 0;
            this.itemContainer2.Name = "itemContainer2";
            this.itemContainer2.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer3});
            // 
            // itemContainer3
            // 
            // 
            // 
            // 
            this.itemContainer3.BackgroundStyle.Class = "RibbonFileMenuColumnOneContainer";
            this.itemContainer3.LayoutOrientation = DevComponents.DotNetBar.eOrientation.Vertical;
            this.itemContainer3.MinimumSize = new System.Drawing.Size(120, 0);
            this.itemContainer3.Name = "itemContainer3";
            this.itemContainer3.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem5,
            this.buttonItem6,
            this.buttonItem3,
            this.buttonDong});
            // 
            // buttonItem3
            // 
            this.buttonItem3.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem3.Image = global::Karaoke_Management.Properties.Resources.dangxuat32;
            this.buttonItem3.ImagePaddingHorizontal = 8;
            this.buttonItem3.Name = "buttonItem3";
            this.buttonItem3.SubItemsExpandWidth = 24;
            this.buttonItem3.Text = "Đăng &xuất";
            this.buttonItem3.Click += new System.EventHandler(this.buttonItem3_Click);
            // 
            // buttonItem5
            // 
            this.buttonItem5.BeginGroup = true;
            this.buttonItem5.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem5.Image = global::Karaoke_Management.Properties.Resources.backup;
            this.buttonItem5.ImagePaddingHorizontal = 8;
            this.buttonItem5.Name = "buttonItem5";
            this.buttonItem5.SubItemsExpandWidth = 24;
            this.buttonItem5.Text = "&Sao lưu dữ liệu";
            // 
            // buttonItem6
            // 
            this.buttonItem6.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem6.Image = global::Karaoke_Management.Properties.Resources.restore;
            this.buttonItem6.ImagePaddingHorizontal = 8;
            this.buttonItem6.Name = "buttonItem6";
            this.buttonItem6.SubItemsExpandWidth = 24;
            this.buttonItem6.Text = "&Phục hồi dữ liệu";
            // 
            // buttonDong
            // 
            this.buttonDong.BeginGroup = true;
            this.buttonDong.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonDong.Image = global::Karaoke_Management.Properties.Resources.Thoat32;
            this.buttonDong.ImagePaddingHorizontal = 8;
            this.buttonDong.Name = "buttonDong";
            this.buttonDong.SubItemsExpandWidth = 24;
            this.buttonDong.Text = "&Đóng";
            this.buttonDong.Click += new System.EventHandler(this.buttonDong_Click);
            // 
            // qatCustomizeItem1
            // 
            this.qatCustomizeItem1.Name = "qatCustomizeItem1";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(540, 459);
            this.ControlBox = false;
            this.Controls.Add(this.ribbonControl1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần mềm quản lý quán Karaoke";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ribbonControl1.ResumeLayout(false);
            this.ribbonControl1.PerformLayout();
            this.ribbonPanel1.ResumeLayout(false);
            this.ribbonPanel2.ResumeLayout(false);
            this.ribbonPanel6.ResumeLayout(false);
            this.ribbonPanel5.ResumeLayout(false);
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl1;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel1;
        private DevComponents.DotNetBar.RibbonBar ribbonBarQuanLyHoaDon;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItemHoaDon;
        private DevComponents.DotNetBar.Office2007StartButton office2007StartButton1;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ItemContainer itemContainer2;
        private DevComponents.DotNetBar.ItemContainer itemContainer3;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.ButtonItem buttonItem5;
        private DevComponents.DotNetBar.ButtonItem buttonItem6;
        private DevComponents.DotNetBar.ButtonItem buttonDong;
        private DevComponents.DotNetBar.QatCustomizeItem qatCustomizeItem1;
        private DevComponents.DotNetBar.ButtonItem buttonItemNhap_HoaDon;
        private DevComponents.DotNetBar.ButtonItem buttonItemTimKiem_HoaDon;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel2;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItemSanPham;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItemNhaCungCap;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItemNhanVien;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel5;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem5;
        private DevComponents.DotNetBar.RibbonBar ribbonBarQuanLyNhaCungCap;
        private DevComponents.DotNetBar.ButtonItem buttonItemThem_NhaCungCap;
        private DevComponents.DotNetBar.ButtonItem buttonItemTimKiem_NhaCungCap;
        private DevComponents.DotNetBar.RibbonBar ribbonBarQuanLySanPham;
        private DevComponents.DotNetBar.ButtonItem buttonItemThem_SanPham;
        private DevComponents.DotNetBar.ButtonItem buttonItemTimKiem_SanPham;
        private DevComponents.DotNetBar.RibbonBar ribbonBarQuanLyNhanVien;
        private DevComponents.DotNetBar.ButtonItem buttonItemThem_NhanVien;
        private DevComponents.DotNetBar.ButtonItem buttonItemTimKiem_NhanVien;
        private DevComponents.DotNetBar.RibbonBar ribbonBarBaoCao;
        private DevComponents.DotNetBar.ButtonItem buttonItemBaoCao;
        private DevComponents.DotNetBar.ButtonItem buttonItemBieuDo;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel6;
        private DevComponents.DotNetBar.RibbonBar ribbonBarTroGiup;
        private DevComponents.DotNetBar.ButtonItem buttonItemThongTinTacGia;
        private DevComponents.DotNetBar.ButtonItem buttonItemThongTinHeThong;
        private DevComponents.DotNetBar.RibbonTabItem ribbonTabItem6;

    }
}