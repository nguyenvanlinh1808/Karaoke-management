﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Karaoke_Management.PresentationLayer
{
    public partial class frmSuaNV : DevComponents.DotNetBar.Office2007Form
    {
        public string mnv;
        // Tạo đối tượng kết nối.
        SqlConnection conn = new SqlConnection("Data Source=NDA-PC\\SQLEXPRESS; Initial Catalog=KaraokeMangement; User Id=sa; password=12345; Integrated Security = true");
        SqlDataAdapter da = new SqlDataAdapter();

        public frmSuaNV()
        {
            InitializeComponent();
        }


        private void buttonHuyBo_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXacNhan_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show(mnv);

             
             decimal Salary;
             string MaCV;
             string Sex;

             if (coBoxCV.Text == "Quản lý")
             {
                 MaCV = "QL";
             }
             else
             {
                 MaCV = "NV";
             }

             if (coBoxSex.Text == "Nam")
             {
                 Sex = "Nam";
             }
             else
             {
                 Sex = "Nữ";
             }

             if (txtLuong.Text == "")
             {
                 Salary = 0;
             }
             else
             {
                 Salary = Convert.ToDecimal(txtLuong.Text);
             }


             // Tạo câu lệnh T-SQL.
             string commandText = "Update NhanVien SET MaNV = @MaNV, TenDN = @TenDN, MatKhau = @MatKhau1, HoTen = @HoTen, GioiTinh = @GioiTinh, NgaySinh = @NgaySinh, DiaChi = @DiaChi, DienThoai = @DienThoai, MaCV = @ChucVu, MucLuong = @MucLuong WHERE MaNV = @MaNV1";
             // Tạo đối tượng thực hiện câu lệnh T-SQL.
             da.UpdateCommand = new SqlCommand(commandText, conn);
             da.UpdateCommand.Parameters.Add("@MaNV1", SqlDbType.VarChar).Value = mnv;
             da.UpdateCommand.Parameters.Add("@MaNV", SqlDbType.VarChar).Value = txtMaNV.Text;
             da.UpdateCommand.Parameters.Add("@TenDN", SqlDbType.VarChar).Value = txtID.Text;
             da.UpdateCommand.Parameters.Add("@MatKhau1", SqlDbType.VarChar).Value = txtPassword.Text;
             da.UpdateCommand.Parameters.Add("@HoTen", SqlDbType.NVarChar).Value = txtHoTen.Text;
             da.UpdateCommand.Parameters.Add("@GioiTinh", SqlDbType.NVarChar).Value = Sex;
             da.UpdateCommand.Parameters.Add("@NgaySinh", SqlDbType.DateTime).Value = DOB.Value;
             da.UpdateCommand.Parameters.Add("@DiaChi", SqlDbType.NVarChar).Value = txtDiaChi.Text;
             da.UpdateCommand.Parameters.Add("@DienThoai", SqlDbType.NVarChar).Value = txtDienThoai.Text;
             da.UpdateCommand.Parameters.Add("@ChucVu", SqlDbType.VarChar).Value = MaCV;
             da.UpdateCommand.Parameters.Add("@MucLuong", SqlDbType.Money).Value = Salary;

             // Mở kết nối trước khi thực hiện lệnh.
             conn.Open();

             // Thực hiện lệnh.
             da.UpdateCommand.ExecuteNonQuery();

             // Đóng kết nối.
             conn.Close();
             this.Close();
         }
        }
    }

