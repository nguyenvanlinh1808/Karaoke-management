﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using Karaoke_Management;

namespace Karaoke_Management.PresentationLayer
{
    public partial class frmTimNV : DevComponents.DotNetBar.Office2007Form
    {
        public string mnv;
        SqlConnection cs = new SqlConnection("Data Source=NDA-PC\\SQLEXPRESS; Initial Catalog=KaraokeMangement; User Id=sa; password=12345; Integrated Security = true");
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        BindingSource tblNhanVien = new BindingSource();

        public frmTimNV()
        {
            InitializeComponent();
        }




        private void btnDongY_Click_1(object sender, EventArgs e)
        {
            cs.Open();
            decimal Salary;
        
            if (txtLuong.Text == "")
            {
                Salary = 0;
            }
            else
            {
                Salary = Convert.ToDecimal(txtLuong.Text);
            }

            da.SelectCommand = new SqlCommand("SELECT MaNV, TenDn, HoTen, GioiTinh, NgaySinh, MaCV, DiaChi, DienThoai, MucLuong FROM NhanVien WHERE (MaNV = @MaNV) OR (TenDN = @TenDN) OR (HoTen = @HoTen) OR (DienThoai = @DienThoai) OR (MucLuong = @MucLuong)", cs);
            da.SelectCommand.Parameters.Add("@MaNV", SqlDbType.VarChar).Value = txtMaNV.Text;
            da.SelectCommand.Parameters.Add("@TenDN", SqlDbType.VarChar).Value = txtTenDN.Text;
            da.SelectCommand.Parameters.Add("@HoTen", SqlDbType.NVarChar).Value = txtHoTen.Text;
            da.SelectCommand.Parameters.Add("@DienThoai", SqlDbType.NVarChar).Value = txtDienThoai.Text;
            da.SelectCommand.Parameters.Add("@MucLuong", SqlDbType.Money).Value = Salary;
            

            ds.Clear();
            da.Fill(ds);
            dg.DataSource = ds.Tables[0];
            da.SelectCommand.ExecuteNonQuery();
            tblNhanVien.DataSource = ds.Tables[0];

            txtMaNV1.DataBindings.Clear();
            txtMaNV1.DataBindings.Add(new Binding("Text", tblNhanVien, "MaNV"));

            txtTenDN1.DataBindings.Clear();
            txtTenDN1.DataBindings.Add(new Binding("Text",tblNhanVien,"TenDN"));

            txtHoTen1.DataBindings.Clear();
            txtHoTen1.DataBindings.Add(new Binding("Text", tblNhanVien, "HoTen"));

            txtGioiTinh.DataBindings.Clear();
            txtGioiTinh.DataBindings.Add(new Binding("Text", tblNhanVien, "GioiTinh"));

            txtNgaySinh.DataBindings.Clear();
            txtNgaySinh.DataBindings.Add(new Binding("Text", tblNhanVien, "NgaySinh"));

            txtMaCV.DataBindings.Clear();
            txtMaCV.DataBindings.Add(new Binding("Text", tblNhanVien, "MaCV"));

            txtDiaChi1.DataBindings.Clear();
            txtDiaChi1.DataBindings.Add(new Binding("Text", tblNhanVien, "DiaChi"));

            txtDienThoai1.DataBindings.Clear();
            txtDienThoai1.DataBindings.Add(new Binding("Text", tblNhanVien, "DienThoai"));

            txtLuong1.DataBindings.Clear();
            txtLuong1.DataBindings.Add(new Binding("Text", tblNhanVien, "MucLuong"));

            mnv = txtMaNV1.Text;

            
            cs.Close();
           
          
        }

        private void buttonHuyBo_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (mnv == "")
            {
                MessageBox.Show("Chưa chọn nhân viên cần sửa thông tin!");
            }
            else
            {
                frmSuaNV frm = new frmSuaNV();
                frm.mnv = this.txtMaNV1.Text;
                frm.Show();
                ds.Clear();
                da.Fill(ds);
            }

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            
            if (mnv == "")
            {
                MessageBox.Show("Chưa chọn nhân viên cần xóa thông tin!");
            }
            else
            {
                DialogResult dr;
                dr = MessageBox.Show("Bạn có muốn xóa nhân viên này không?", "Xóa nhân viên", MessageBoxButtons.YesNo);

                if (dr == DialogResult.Yes)
                {

                    cs.Open();
                    da.DeleteCommand = new SqlCommand("DELETE FROM NhanVien WHERE MaNV = @MaNV", cs);
                    da.DeleteCommand.Parameters.Add("@MaNV", SqlDbType.VarChar).Value = mnv;

                    da.DeleteCommand.ExecuteNonQuery();
                    cs.Close();

                    ds.Clear();
                    da.Fill(ds);
                }
            }
        }
    }
}
