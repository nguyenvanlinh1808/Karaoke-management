﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Karaoke_Management.PresentationLayer;
using Karaoke_Management.Initiation;

namespace Karaoke_Management.PresentationLayer
{
    public partial class frmMain : DevComponents.DotNetBar.Office2007RibbonForm
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void buttonDong_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonItemThem_NhanVien_Click(object sender, EventArgs e)
        {
            if (KhoiTao.themNV == null || KhoiTao.themNV.IsDisposed)
            {
                KhoiTao.themNV = new frmThemNV();
                KhoiTao.themNV.ShowDialog();
            }
            KhoiTao.themNV.Dispose();
        }

        private void buttonItemTimKiem_NhanVien_Click(object sender, EventArgs e)
        {
            if (KhoiTao.timNV == null || KhoiTao.timNV.IsDisposed)
            {
                KhoiTao.timNV = new frmTimNV();
                KhoiTao.timNV.ShowDialog();
            }
            KhoiTao.timNV.Dispose();
        }

        private void buttonItemThem_NhaCungCap_Click(object sender, EventArgs e)
        {
            if (KhoiTao.themNCC == null || KhoiTao.themNCC.IsDisposed)
            {
                KhoiTao.themNCC = new frmThemNCC();
                KhoiTao.themNCC.ShowDialog();
            }
            KhoiTao.themNCC.Dispose();
        }

        private void buttonItemTimKiem_NhaCungCap_Click(object sender, EventArgs e)
        {
            if (KhoiTao.timNCC == null || KhoiTao.timNCC.IsDisposed)
            {
                KhoiTao.timNCC = new frmTimNCC();
                KhoiTao.timNCC.ShowDialog();
            }
            KhoiTao.timNCC.Dispose();
        }

        private void buttonItemThem_SanPham_Click(object sender, EventArgs e)
        {
            if (KhoiTao.themSP == null || KhoiTao.themSP.IsDisposed)
            {
                KhoiTao.themSP = new frmThemSP();
                KhoiTao.themSP.ShowDialog();
            }
            KhoiTao.themSP.Dispose();
        }

        private void buttonItemTimKiem_SanPham_Click(object sender, EventArgs e)
        {
            if (KhoiTao.timSP == null || KhoiTao.timSP.IsDisposed)
            {
                KhoiTao.timSP = new frmTimSP();
                KhoiTao.timSP.ShowDialog();
            }
            KhoiTao.timSP.Dispose();
        }

        private void buttonItemNhap_HoaDon_Click(object sender, EventArgs e)
        {
            if (KhoiTao.nhapHDCT == null || KhoiTao.nhapHDCT.IsDisposed)
            {
                KhoiTao.nhapHDCT = new frmNhapHDCT();
                KhoiTao.nhapHDCT.ShowDialog();
            }
            KhoiTao.nhapHDCT.Dispose();
        }

        private void buttonItemTimKiem_HoaDon_Click(object sender, EventArgs e)
        {
            if (KhoiTao.timHD == null || KhoiTao.timHD.IsDisposed)
            {
                KhoiTao.timHD = new frmTimHD();
                KhoiTao.timHD.ShowDialog();
            }
            KhoiTao.timHD.Dispose();
        }

        private void buttonItemBaoCao_Click(object sender, EventArgs e)
        {
            if (KhoiTao.kiemKe == null || KhoiTao.kiemKe.IsDisposed)
            {
                KhoiTao.kiemKe = new frmKiemKe();
                KhoiTao.kiemKe.ShowDialog();
            }
            KhoiTao.kiemKe.Dispose();
        }

        private void buttonItem3_Click(object sender, EventArgs e)
        {
            if (KhoiTao.login == null || KhoiTao.kiemKe.IsDisposed)
            {
                this.Close();
                KhoiTao.login = new frmLogin();
                KhoiTao.login.ShowDialog();
            }
            KhoiTao.login.Dispose();
        }
    }
}
