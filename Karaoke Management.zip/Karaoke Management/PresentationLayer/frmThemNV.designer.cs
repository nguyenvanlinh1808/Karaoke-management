﻿namespace Karaoke_Management.PresentationLayer
{
    partial class frmThemNV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmThemNV));
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.btnXacNhan = new DevComponents.DotNetBar.ButtonX();
            this.buttonHuyBo = new DevComponents.DotNetBar.ButtonX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.panelEx1 = new DevComponents.DotNetBar.PanelEx();
            this.txtPassword = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtID = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtLuong = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.coBoxCV = new System.Windows.Forms.ComboBox();
            this.txtDienThoai = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtDiaChi = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.coBoxSex = new System.Windows.Forms.ComboBox();
            this.txtHoTen = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.txtMaNV = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.panelEx1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelX1
            // 
            this.labelX1.Location = new System.Drawing.Point(21, 36);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(79, 19);
            this.labelX1.TabIndex = 1;
            this.labelX1.Text = "Họ Tên";
            // 
            // labelX8
            // 
            this.labelX8.Location = new System.Drawing.Point(21, 254);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(79, 19);
            this.labelX8.TabIndex = 1;
            this.labelX8.Text = "Tên đăng nhập";
            // 
            // labelX9
            // 
            this.labelX9.Location = new System.Drawing.Point(21, 279);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(79, 19);
            this.labelX9.TabIndex = 1;
            this.labelX9.Text = "Mật khẩu";
            // 
            // labelX2
            // 
            this.labelX2.Location = new System.Drawing.Point(21, 89);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(79, 19);
            this.labelX2.TabIndex = 1;
            this.labelX2.Text = "Ngày sinh";
            // 
            // labelX3
            // 
            this.labelX3.Location = new System.Drawing.Point(21, 63);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(79, 19);
            this.labelX3.TabIndex = 1;
            this.labelX3.Text = "Giới tính";
            // 
            // labelX4
            // 
            this.labelX4.Location = new System.Drawing.Point(21, 114);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(79, 19);
            this.labelX4.TabIndex = 1;
            this.labelX4.Text = "Địa chỉ";
            // 
            // labelX5
            // 
            this.labelX5.Location = new System.Drawing.Point(21, 141);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(79, 19);
            this.labelX5.TabIndex = 1;
            this.labelX5.Text = "Điện thoại";
            // 
            // labelX6
            // 
            this.labelX6.Location = new System.Drawing.Point(21, 166);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(79, 19);
            this.labelX6.TabIndex = 1;
            this.labelX6.Text = "Chức vụ";
            // 
            // labelX7
            // 
            this.labelX7.Location = new System.Drawing.Point(21, 191);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(79, 19);
            this.labelX7.TabIndex = 1;
            this.labelX7.Text = "Mức lương";
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnXacNhan.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnXacNhan.Image = ((System.Drawing.Image)(resources.GetObject("btnXacNhan.Image")));
            this.btnXacNhan.Location = new System.Drawing.Point(41, 324);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(110, 22);
            this.btnXacNhan.TabIndex = 3;
            this.btnXacNhan.Text = "Xác nhận";
            this.btnXacNhan.Click += new System.EventHandler(this.btnXacNhan_Click);
            // 
            // buttonHuyBo
            // 
            this.buttonHuyBo.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonHuyBo.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonHuyBo.Image = ((System.Drawing.Image)(resources.GetObject("buttonHuyBo.Image")));
            this.buttonHuyBo.Location = new System.Drawing.Point(183, 324);
            this.buttonHuyBo.Name = "buttonHuyBo";
            this.buttonHuyBo.Size = new System.Drawing.Size(110, 22);
            this.buttonHuyBo.TabIndex = 3;
            this.buttonHuyBo.Text = "Hủy bỏ";
            this.buttonHuyBo.Click += new System.EventHandler(this.buttonHuyBo_Click);
            // 
            // labelX11
            // 
            this.labelX11.Location = new System.Drawing.Point(21, 10);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(75, 23);
            this.labelX11.TabIndex = 5;
            this.labelX11.Text = "Mã nhân viên";
            // 
            // panelEx1
            // 
            this.panelEx1.CanvasColor = System.Drawing.SystemColors.Control;
            this.panelEx1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.panelEx1.Controls.Add(this.txtPassword);
            this.panelEx1.Controls.Add(this.txtID);
            this.panelEx1.Controls.Add(this.txtLuong);
            this.panelEx1.Controls.Add(this.coBoxCV);
            this.panelEx1.Controls.Add(this.txtDienThoai);
            this.panelEx1.Controls.Add(this.txtDiaChi);
            this.panelEx1.Controls.Add(this.DOB);
            this.panelEx1.Controls.Add(this.coBoxSex);
            this.panelEx1.Controls.Add(this.txtHoTen);
            this.panelEx1.Controls.Add(this.txtMaNV);
            this.panelEx1.Controls.Add(this.labelX11);
            this.panelEx1.Controls.Add(this.buttonHuyBo);
            this.panelEx1.Controls.Add(this.btnXacNhan);
            this.panelEx1.Controls.Add(this.labelX7);
            this.panelEx1.Controls.Add(this.labelX6);
            this.panelEx1.Controls.Add(this.labelX5);
            this.panelEx1.Controls.Add(this.labelX4);
            this.panelEx1.Controls.Add(this.labelX3);
            this.panelEx1.Controls.Add(this.labelX2);
            this.panelEx1.Controls.Add(this.labelX9);
            this.panelEx1.Controls.Add(this.labelX8);
            this.panelEx1.Controls.Add(this.labelX1);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEx1.Location = new System.Drawing.Point(0, 0);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(328, 379);
            this.panelEx1.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.panelEx1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.panelEx1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.panelEx1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.panelEx1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.panelEx1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.panelEx1.Style.GradientAngle = 90;
            this.panelEx1.TabIndex = 0;
            // 
            // txtPassword
            // 
            // 
            // 
            // 
            this.txtPassword.Border.Class = "TextBoxBorder";
            this.txtPassword.Location = new System.Drawing.Point(125, 277);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(186, 20);
            this.txtPassword.TabIndex = 15;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // txtID
            // 
            // 
            // 
            // 
            this.txtID.Border.Class = "TextBoxBorder";
            this.txtID.Location = new System.Drawing.Point(125, 254);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(186, 20);
            this.txtID.TabIndex = 14;
            // 
            // txtLuong
            // 
            // 
            // 
            // 
            this.txtLuong.Border.Class = "TextBoxBorder";
            this.txtLuong.Location = new System.Drawing.Point(102, 189);
            this.txtLuong.Name = "txtLuong";
            this.txtLuong.Size = new System.Drawing.Size(209, 20);
            this.txtLuong.TabIndex = 13;
            // 
            // coBoxCV
            // 
            this.coBoxCV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.coBoxCV.ForeColor = System.Drawing.SystemColors.WindowText;
            this.coBoxCV.FormattingEnabled = true;
            this.coBoxCV.Items.AddRange(new object[] {
            "Quản lý",
            "Nhân Viên"});
            this.coBoxCV.Location = new System.Drawing.Point(102, 163);
            this.coBoxCV.Name = "coBoxCV";
            this.coBoxCV.Size = new System.Drawing.Size(209, 21);
            this.coBoxCV.TabIndex = 12;
            // 
            // txtDienThoai
            // 
            // 
            // 
            // 
            this.txtDienThoai.Border.Class = "TextBoxBorder";
            this.txtDienThoai.Location = new System.Drawing.Point(102, 140);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(209, 20);
            this.txtDienThoai.TabIndex = 11;
            // 
            // txtDiaChi
            // 
            // 
            // 
            // 
            this.txtDiaChi.Border.Class = "TextBoxBorder";
            this.txtDiaChi.Location = new System.Drawing.Point(102, 113);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(209, 20);
            this.txtDiaChi.TabIndex = 10;
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(102, 88);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(209, 20);
            this.DOB.TabIndex = 9;
            // 
            // coBoxSex
            // 
            this.coBoxSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.coBoxSex.ForeColor = System.Drawing.SystemColors.WindowText;
            this.coBoxSex.FormattingEnabled = true;
            this.coBoxSex.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.coBoxSex.Location = new System.Drawing.Point(102, 60);
            this.coBoxSex.Name = "coBoxSex";
            this.coBoxSex.Size = new System.Drawing.Size(209, 21);
            this.coBoxSex.TabIndex = 8;
            // 
            // txtHoTen
            // 
            // 
            // 
            // 
            this.txtHoTen.Border.Class = "TextBoxBorder";
            this.txtHoTen.Location = new System.Drawing.Point(102, 35);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(209, 20);
            this.txtHoTen.TabIndex = 7;
            // 
            // txtMaNV
            // 
            // 
            // 
            // 
            this.txtMaNV.Border.Class = "TextBoxBorder";
            this.txtMaNV.Location = new System.Drawing.Point(102, 10);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(209, 20);
            this.txtMaNV.TabIndex = 6;
            // 
            // frmThemNV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 379);
            this.Controls.Add(this.panelEx1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmThemNV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thêm Nhân Viên";
            this.panelEx1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.ButtonX btnXacNhan;
        private DevComponents.DotNetBar.ButtonX buttonHuyBo;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.PanelEx panelEx1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtMaNV;
        private DevComponents.DotNetBar.Controls.TextBoxX txtHoTen;
        private System.Windows.Forms.ComboBox coBoxSex;
        private DevComponents.DotNetBar.Controls.TextBoxX txtDiaChi;
        private System.Windows.Forms.DateTimePicker DOB;
        private DevComponents.DotNetBar.Controls.TextBoxX txtDienThoai;
        private System.Windows.Forms.ComboBox coBoxCV;
        private DevComponents.DotNetBar.Controls.TextBoxX txtLuong;
        private DevComponents.DotNetBar.Controls.TextBoxX txtPassword;
        private DevComponents.DotNetBar.Controls.TextBoxX txtID;

    }
}